import sys
import serial
import serial.tools.list_ports
from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QLineEdit, QPushButton, QComboBox, QTextEdit,
    QGroupBox, QFormLayout, QMessageBox
)
from PyQt5.QtCore import QThread, pyqtSignal
import re
import time


class SerialReader(QThread):
    data_received = pyqtSignal(str)

    def __init__(self, ser):
        super().__init__()
        self.ser = ser
        self.running = True

    def run(self):
        buffer = ""
        while self.running and self.ser.is_open:
            try:
                if self.ser.in_waiting:
                    chunk = self.ser.read(self.ser.in_waiting).decode('utf-8', errors='ignore')
                    buffer += chunk
                    if '\r\n' in buffer:
                        lines = buffer.split('\r\n')
                        buffer = lines[-1]
                        for line in lines[:-1]:
                            if line.strip():
                                self.data_received.emit(line)
            except Exception as e:
                self.data_received.emit(f"ERROR: {e}")
                break
        self.ser.close()

    def stop(self):
        self.running = False


class LANControlGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.ser = None
        self.reader_thread = None
        self.initUI()

    def initUI(self):
        self.setWindowTitle("LAN Control")
        self.resize(520, 520)  # Уже и чуть ниже
        layout = QVBoxLayout()

        # === Port & Connect ===
        top_layout = QHBoxLayout()
        self.port_combo = QComboBox()
        self.refresh_ports()
        self.connect_btn = QPushButton("Connect")
        self.connect_btn.clicked.connect(self.toggle_connection)

        top_layout.addWidget(QLabel("Port:"))
        top_layout.addWidget(self.port_combo, 1)
        top_layout.addWidget(self.connect_btn)

        refresh_ports_btn = QPushButton("Refresh")
        refresh_ports_btn.clicked.connect(self.refresh_ports)
        top_layout.addWidget(refresh_ports_btn)

        layout.addLayout(top_layout)

        # === Network Settings ===
        net_group = QGroupBox("Network")
        net_layout = QFormLayout()
        net_layout.setSpacing(5)
        self.ip_edit = QLineEdit("192.168.0.250")
        self.mac_edit = QLineEdit("00:08:DC:AB:CD:EF")
        self.subnet_edit = QLineEdit("255.255.255.0")
        self.gateway_edit = QLineEdit("192.168.0.1")
        self.dns_edit = QLineEdit("8.8.8.8")

        net_layout.addRow("IP:", self.ip_edit)
        net_layout.addRow("MAC:", self.mac_edit)
        net_layout.addRow("Mask:", self.subnet_edit)
        net_layout.addRow("GW:", self.gateway_edit)
        net_layout.addRow("DNS:", self.dns_edit)
        net_group.setLayout(net_layout)
        layout.addWidget(net_group)

        # === Button Names ===
        buttons_group = QGroupBox("Buttons")
        buttons_layout = QFormLayout()
        buttons_layout.setSpacing(3)
        self.button_edits = []
        row_layouts = [QHBoxLayout() for _ in range(4)]
        for i in range(8):
            edit = QLineEdit(f"OUT{i+1}")
            self.button_edits.append(edit)
            # Две кнопки в строке
            row_idx = i // 2
            row_layouts[row_idx].addWidget(QLabel(f"{i}:"))
            row_layouts[row_idx].addWidget(edit, 1)
        for row in row_layouts:
            buttons_layout.addRow(row)
        buttons_group.setLayout(buttons_layout)
        layout.addWidget(buttons_group)

        # === Buttons ===
        btn_layout = QHBoxLayout()
        self.refresh_btn = QPushButton("Refresh")
        self.refresh_btn.clicked.connect(self.refresh_all)
        self.apply_btn = QPushButton("Apply")
        self.apply_btn.clicked.connect(self.apply_settings)
        self.save_btn = QPushButton("Save EEPROM")
        self.save_btn.clicked.connect(self.save_to_eeprom)

        btn_layout.addWidget(self.refresh_btn)
        btn_layout.addWidget(self.apply_btn)
        btn_layout.addWidget(self.save_btn)
        layout.addLayout(btn_layout)

        # === Log Output ===
        self.log_output = QTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setMaximumHeight(100)
        self.log_output.setStyleSheet("font-family: monospace; font-size: 8pt; padding: 4px;")
        layout.addWidget(QLabel("Log:"))
        layout.addWidget(self.log_output)

        self.setLayout(layout)
        self.set_controls_enabled(False)

    def set_controls_enabled(self, enabled):
        self.refresh_btn.setEnabled(enabled)
        self.apply_btn.setEnabled(enabled)
        self.save_btn.setEnabled(enabled)
        for edit in [self.ip_edit, self.mac_edit, self.subnet_edit, self.gateway_edit, self.dns_edit]:
            edit.setEnabled(enabled)
        for edit in self.button_edits:
            edit.setEnabled(enabled)

    def refresh_ports(self):
        self.port_combo.clear()
        ports = serial.tools.list_ports.comports()
        for port in ports:
            self.port_combo.addItem(f"{port.device}")

    def toggle_connection(self):
        if self.ser and self.ser.is_open:
            self.disconnect_serial()
        else:
            self.connect_serial()

    def connect_serial(self):
        port_name = self.port_combo.currentText()
        try:
            self.ser = serial.Serial(port_name, 115200, timeout=0.5)
            time.sleep(1.5)  # Короче задержка после подключения
            self.reader_thread = SerialReader(self.ser)
            self.reader_thread.data_received.connect(self.on_data_received)
            self.reader_thread.start()
            self.connect_btn.setText("Disconnect")
            self.set_controls_enabled(True)
            self.log("✅ Connected")
            self.refresh_all()
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Cannot connect: {e}")

    def disconnect_serial(self):
        if self.reader_thread:
            self.reader_thread.stop()
            self.reader_thread.wait()
        self.connect_btn.setText("Connect")
        self.set_controls_enabled(False)
        self.log("🔌 Disconnected")

    def log(self, msg):
        self.log_output.append(f"> {msg}")

    def send_command(self, cmd, delay=None):
        if delay is None:
            delay = 0.1  # Быстрые команды
            if cmd in ["buttons", "network"]:
                delay = 0.3  # Чуть больше на чтение
            elif cmd == "save":
                delay = 0.4  # Сохранение может занять чуть больше
        if not self.ser or not self.ser.is_open:
            self.log("❌ Not connected!")
            return
        self.ser.write(f"{cmd}\r\n".encode())
        self.log(f"📤 {cmd}")
        time.sleep(delay)  # Минимальные задержки

    def on_data_received(self, line):
        # Парсинг IP
        if "IP:" in line:
            match = re.search(r"IP: (\d+\.\d+\.\d+\.\d+)", line)
            if match:
                self.ip_edit.setText(match.group(1))
        elif "MAC:" in line:
            match = re.search(r"MAC: ([0-9A-F:]{17})", line, re.IGNORECASE)
            if match:
                self.mac_edit.setText(match.group(1).upper())
        elif "Subnet:" in line:
            match = re.search(r"Subnet: (\d+\.\d+\.\d+\.\d+)", line)
            if match:
                self.subnet_edit.setText(match.group(1))
        elif "Gateway:" in line:
            match = re.search(r"Gateway: (\d+\.\d+\.\d+\.\d+)", line)
            if match:
                self.gateway_edit.setText(match.group(1))
        elif "DNS:" in line:
            match = re.search(r"DNS: (\d+\.\d+\.\d+\.\d+)", line)
            if match:
                self.dns_edit.setText(match.group(1))
        # Парсинг имён кнопок
        elif "Button" in line and ":" in line and "Button Names" not in line:
            match = re.search(r"Button (\d+):\s*(.+)", line)
            if match:
                idx = int(match.group(1))
                if 0 <= idx < 8:
                    name = match.group(2).strip()
                    if name:
                        self.button_edits[idx].setText(name)
        # Показать всё в логе
        self.log(f"📥 {line}")

    def refresh_all(self):
        self.send_command("network")
        self.send_command("buttons")

    def apply_settings(self):
        ip = self.ip_edit.text().strip()
        mac = self.mac_edit.text().strip()
        sn = self.subnet_edit.text().strip()
        gw = self.gateway_edit.text().strip()
        dns = self.dns_edit.text().strip()

        self.send_command(f"set ip {ip}")
        self.send_command(f"set mac {mac}")
        self.send_command(f"set subnet {sn}")
        self.send_command(f"set gateway {gw}")
        self.send_command(f"set dns {dns}")

        for i in range(8):
            name = self.button_edits[i].text().strip()
            if name:
                self.send_command(f"setbutton {i} {name}")

        QMessageBox.information(self, "Applied", "Settings applied to device.")

    def save_to_eeprom(self):
        reply = QMessageBox.question(
            self, "Confirm",
            "Save to EEPROM?",
            QMessageBox.Yes | QMessageBox.No
        )
        if reply == QMessageBox.Yes:
            self.send_command("save")
            self.log("💾 Saved to EEPROM")

    def closeEvent(self, event):
        if self.ser and self.ser.is_open:
            self.disconnect_serial()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = LANControlGUI()
    window.show()
    sys.exit(app.exec_())